import random
secret_number = random.randint(0, 30)
start = str(input("wanna play a number guessing game? "))
if (start == "yes" or start == "Yes"):
  print("let's begin!")  
  print("the number i'm thinking of is somewhere between 1-30 make your guess")
  while True:
    guess = int(input(" "))
    if (guess > 30):
      print("hint: the number i'm thinking of is below 30")
    elif (guess == secret_number):
      print("nice, you got it!")
    elif (guess < secret_number):
      print("too low! guess higher")
    elif (guess > secret_number):
      print("too high! guess lower")
elif (start == "no" or start == "No"):
  print("ok bye")

